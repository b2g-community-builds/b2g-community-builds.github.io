#!/bin/bash -vex

# Ensure all the scripts in this dir are on the path....
DIRNAME=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
PATH=$DIRNAME:$PATH

WORKSPACE=$1

### Check that require variables are defined
test -d $WORKSPACE
export WORKSPACE
test $GECKO_HEAD_REPOSITORY # Should be an hg repository url to pull from
test $GECKO_BASE_REPOSITORY # Should be an hg repository url to clone from
test $GECKO_HEAD_REV # Should be an hg revision to pull down
test $TARGET
export TARGET
test $VARIANT

. ../builder/setup-ccache.sh

# Figure out where the remote manifest.
B2G_CONFIG="https://github.com/b2g-community-builds/b2g-config.git"
BLOBS="http://b2g-community-builds.github.io/blobs-zips/$TARGET.tar.bz2"

git clone $B2G_CONFIG $WORKSPACE/b2g-config
cp $WORKSPACE/b2g-config/$TARGET/sources.xml $WORKSPACE/sources.xml

git config --global --add color.ui auto
git clone https://git.mozilla.org/b2g/B2G.git $WORKSPACE/B2G
cd $WORKSPACE/B2G
git init $WORKSPACE/B2G/.tc-vcs-manifest
cd $WORKSPACE/B2G/.tc-vcs-manifest
cp $WORKSPACE/b2g-config/$TARGET/sources.xml sources.xml
git add --all
git commit -m manifest
git branch -m master
cd $WORKSPACE/B2G
./repo init -b master -u $WORKSPACE/B2G/.tc-vcs-manifest -m sources.xml --repo-url https://git.mozilla.org/external/google/gerrit/git-repo.git --repo-branch master
./repo sync -j100 -q

# Ensure symlink has been created to gecko...
rm -rf $WORKSPACE/B2G/gecko
ln -s $WORKSPACE/gecko $WORKSPACE/B2G/gecko

debug_flag=""
if [ 0$B2G_DEBUG -ne 0 ]; then
  debug_flag='--debug'
fi

curl -L $BLOBS -o $WORKSPACE/$TARGET.tar.bz2
