#! /bin/bash -vex

. pre-build.sh

rm -rf $WORKSPACE/B2G/objdir*
rm -rf $WORKSPACE/B2G/out

MOZHARNESS_CONFIG=${MOZHARNESS_CONFIG:=b2g/taskcluster-phone.py}

rm -rf $WORKSPACE/B2G/upload/

$WORKSPACE/gecko/testing/mozharness/scripts/b2g_build.py \
  --config $MOZHARNESS_CONFIG \
  "$debug_flag" \
  --disable-mock \
  --variant=$VARIANT \
  --work-dir=$WORKSPACE/B2G \
  --gaia-languages-file locales/languages_all.json \
  --log-level=debug \
  --target=$TARGET \
  --b2g-config-dir=../../../../b2g-config/$TARGET \
  --gecko-config=$WORKSPACE/b2g-config/$TARGET/config.json \
  --checkout-revision=$GECKO_HEAD_REV \
  --repo=$WORKSPACE/gecko

if [ $TARGET == "i9300" ]
then
  cd $WORKSPACE/B2G/out/target/product/i9300/
  tar -H ustar -c boot.img system.img userdata.img > B2G-I9300.PDA.tar
  md5sum -t B2G-I9300.PDA.tar >> B2G-I9300.PDA.tar
  mv B2G-I9300.PDA.tar $WORKSPACE/B2G/upload/B2G-I9300.PDA.tar.md5
  cd $WORKSPACE/gecko/testing/taskcluster/scripts/community-phone-builder
fi

. post-build.sh
